import Counter from './components/Counter'

import './App.css'

// Replace your code here
const App = () => <Counter />

export default App
